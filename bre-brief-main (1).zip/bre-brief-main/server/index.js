import 'dotenv/config'
import crypto from 'node:crypto'
import express from 'express'
import cors from 'cors'
import OpenAI from 'openai'

const PORT = process.env.PORT || 3001
const ALLOWED_ORIGINS = process.env.ALLOWED_ORIGINS
  ? process.env.ALLOWED_ORIGINS.split(',').map((o) => o.trim())
  : ['http://localhost:5173']

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY })

const llmConfig = {
  model: 'gpt-5.2',
  reasoningEffort: 'high',
  maxOutputTokens: 16_000,

  systemPrompt: `You are an expert Business Analyst and Technical Writer who explains JSONata code used in a Business Rules Engine.

Before writing, carefully review any custom instructions, notes, or additional information provided by the user, and use them to shape the explanation.

Read the provided context, which may include a request body, transformation query, response payload, sample input/output, and supporting notes, and write clear Markdown documentation that explains what the code is doing. The audience is a credit manager or business stakeholder who wants to understand the logic, the sequence of conditions, the purpose of each assignment or override, why the logic is being applied, and how the output is derived.

Explain the code in the same order as it is written, line by line or block by block, so the explanation is easy to map back to the rule. Choose the structure that best explains the logic based on the code itself. Do not follow a fixed template. You can use sections, bullets, numbering, or tables to improve clarity.

Keep the language simple, direct, and professional. Avoid flowery language. Use technical terms only when needed for accuracy or when they already appear in the input.

When interpreting the rule, use these patterns only where they are supported by the code:
- These JSONata rules are often written as step-by-step transformations, where a value is first assigned and then reassigned by later conditions. Later lines can override earlier results.
- Source-based selection is common. A field such as compute_source may be used to choose between source-specific values, such as SCUW3 and SCUW4.
- Some rules define helper functions to standardize check results. These functions may return structured objects containing fields such as result category, reason, identifier, and rejection code.
- When a helper function defined in the rule is invoked elsewhere, do not explain the call in isolation. At the point where the helper is used, recap its relevant behavior — its inputs, what it checks or transforms, and what it returns — so the reader can understand the full effect of that call without needing to jump back to the helper's definition. If the same helper is called in multiple places, repeat or briefly cross-reference the recap at each call site so each section is self-contained. The goal is that any block of explanation, including the parts that invoke sub-functions, gives a complete understanding of what is happening at that point in the rule.
- Null handling and fallback values are important. Rules may replace nulls with defaults such as 0, empty text, empty lists, default result objects, or special prefixed statuses when a check cannot be evaluated.
- After running checks, the code may filter, narrow, or summarize results to keep the applicable outcome or derive output fields such as a consolidated list of codes.
- Outputs may contain both final values and supporting fields such as intermediate values, source-specific values, or the original input for traceability.
- Treat organisation-specific labels as business labels whose meaning should be explained from their usage in the rule, not guessed beyond what the code shows.
- Donot explain any other languages than JSONata. Simply say "This doesn't look like JSONata code to me, please provide a JSONata code to generate the documentation.". Donot write any commentary or explanation that why you cannot generate the documentation for code other than JSONata.
- Do not make the documentation too long unncessarily. Try to keep it concise and to the point.

If the intent of a rule is clear, explain it in simple business language, but do not invent meaning that is not supported by the code. If something is ambiguous or missing, briefly note it.

Return only the final documentation in well-formatted Markdown, without any comments, not even for your decision of what structure you used for writing.`,
}



const ALLOWED_LANGUAGES = ['jsonata', 'drools', 'dmn', 'sql-rules']
const MAX_OCR_TEXT_LENGTH = 50_000
const MAX_CONTEXT_LENGTH = 10_000
const MAX_FILENAME_LENGTH = 255

// ---------------------------------------------------------------------------
// Rate limiter — sliding window per IP
// ---------------------------------------------------------------------------
const RATE_WINDOW_MS = parseInt(process.env.RATE_WINDOW_MS, 10) || 60_000
const RATE_MAX_REQUESTS = parseInt(process.env.RATE_MAX_REQUESTS, 10) || 5

const ipHits = new Map()

function rateLimit(req, res, next) {
  const ip = req.ip || req.socket.remoteAddress
  const now = Date.now()

  if (!ipHits.has(ip)) ipHits.set(ip, [])
  const timestamps = ipHits.get(ip).filter((t) => now - t < RATE_WINDOW_MS)
  timestamps.push(now)
  ipHits.set(ip, timestamps)

  res.setHeader('X-RateLimit-Limit', RATE_MAX_REQUESTS)
  res.setHeader('X-RateLimit-Remaining', Math.max(0, RATE_MAX_REQUESTS - timestamps.length))
  res.setHeader('X-RateLimit-Reset', Math.ceil((timestamps[0] + RATE_WINDOW_MS) / 1000))

  if (timestamps.length > RATE_MAX_REQUESTS) {
    const retryAfter = Math.ceil((timestamps[0] + RATE_WINDOW_MS - now) / 1000)
    res.setHeader('Retry-After', retryAfter)
    return res.status(429).json({
      error: `Too many requests. Try again in ${retryAfter}s.`,
    })
  }
  next()
}

// Periodically purge stale entries so the map doesn't grow forever
setInterval(() => {
  const cutoff = Date.now() - RATE_WINDOW_MS
  for (const [ip, timestamps] of ipHits) {
    const fresh = timestamps.filter((t) => t > cutoff)
    if (fresh.length === 0) ipHits.delete(ip)
    else ipHits.set(ip, fresh)
  }
}, RATE_WINDOW_MS)

// ---------------------------------------------------------------------------
// Concurrency guard — only N LLM calls in flight at once
// ---------------------------------------------------------------------------
const MAX_CONCURRENT = parseInt(process.env.MAX_CONCURRENT, 10) || 3
let inFlight = 0

function concurrencyGuard(_req, res, next) {
  if (inFlight >= MAX_CONCURRENT) {
    return res.status(503).json({ error: 'Server is busy. Please try again shortly.' })
  }
  inFlight++
  res.on('finish', () => inFlight--)
  res.on('close', () => inFlight--)
  next()
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
function buildUserPrompt({ ocrText, additionalContext, fileName, language }) {
  const parts = [
    `## Source File\n**${fileName}** (${language})`,
    `## OCR-Extracted Text\n\`\`\`\n${ocrText}\n\`\`\``,
  ]

  if (additionalContext?.trim()) {
    parts.push(
      `## Additional Context Provided by User\n${additionalContext.trim()}`,
    )
  }

  parts.push(
    '## Task\nProduce the complete business documentation in Markdown based on the source above.',
  )

  return parts.join('\n\n')
}

function sanitize(str) {
  return str.replace(/[\x00-\x08\x0b\x0c\x0e-\x1f]/g, '')
}

// ---------------------------------------------------------------------------
// Express app
// ---------------------------------------------------------------------------
const app = express()

app.use(cors({ origin: ALLOWED_ORIGINS }))
app.use(express.json({ limit: '2mb' }))

// Security headers for every response
app.use((_req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff')
  res.setHeader('X-Frame-Options', 'DENY')
  next()
})

app.post('/api/generate', rateLimit, concurrencyGuard, async (req, res) => {
  const { ocrText, additionalContext, fileName, language } = req.body

  // --- Validation -----------------------------------------------------------
  if (!ocrText || typeof ocrText !== 'string') {
    return res.status(400).json({ error: 'ocrText is required and must be a string.' })
  }
  if (!fileName || typeof fileName !== 'string') {
    return res.status(400).json({ error: 'fileName is required and must be a string.' })
  }
  if (!language || typeof language !== 'string') {
    return res.status(400).json({ error: 'language is required and must be a string.' })
  }
  if (!ALLOWED_LANGUAGES.includes(language.toLowerCase())) {
    return res.status(400).json({ error: `Unsupported language. Allowed: ${ALLOWED_LANGUAGES.join(', ')}` })
  }
  if (ocrText.length > MAX_OCR_TEXT_LENGTH) {
    return res.status(400).json({ error: `ocrText exceeds the ${MAX_OCR_TEXT_LENGTH} character limit.` })
  }
  if (additionalContext && typeof additionalContext === 'string' && additionalContext.length > MAX_CONTEXT_LENGTH) {
    return res.status(400).json({ error: `additionalContext exceeds the ${MAX_CONTEXT_LENGTH} character limit.` })
  }
  if (fileName.length > MAX_FILENAME_LENGTH) {
    return res.status(400).json({ error: 'fileName is too long.' })
  }

  const clean = {
    ocrText: sanitize(ocrText),
    additionalContext: additionalContext ? sanitize(additionalContext) : '',
    fileName: sanitize(fileName).slice(0, MAX_FILENAME_LENGTH),
    language,
  }

  const requestId = crypto.randomUUID()
  console.log(`[${requestId}] generate — ip=${req.ip} lang=${language} chars=${ocrText.length}`)

  const userMessage = buildUserPrompt(clean)

  try {
    const stream = await openai.chat.completions.create({
      model: llmConfig.model,
      reasoning_effort: llmConfig.reasoningEffort,
      max_completion_tokens: llmConfig.maxOutputTokens,
      stream: true,
      messages: [
        { role: 'system', content: llmConfig.systemPrompt },
        { role: 'user', content: userMessage },
      ],
    })

    res.setHeader('Content-Type', 'text/event-stream')
    res.setHeader('Cache-Control', 'no-cache')
    res.setHeader('Connection', 'keep-alive')
    res.flushHeaders()

    for await (const event of stream) {
      const token = event.choices[0]?.delta?.content
      if (token) {
        res.write(`data: ${JSON.stringify({ token })}\n\n`)
      }
    }

    res.write('data: [DONE]\n\n')
    res.end()
    console.log(`[${requestId}] complete`)
  } catch (err) {
    console.error(`[${requestId}] error — ${err.message}`)
    if (!res.headersSent) {
      res.status(500).json({ error: err.message || 'LLM request failed' })
    } else {
      res.write(`data: ${JSON.stringify({ error: err.message })}\n\n`)
      res.end()
    }
  }
})

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`)
  console.log(`Rate limit: ${RATE_MAX_REQUESTS} requests per ${RATE_WINDOW_MS / 1000}s window`)
  console.log(`Max concurrent LLM calls: ${MAX_CONCURRENT}`)
})
